---
layout: default
title: "Lecture 1: Visual Research"
has_children: false
parent: "Lectures"
nav_order: 1
---

#First Lecture
